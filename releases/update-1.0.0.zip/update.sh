#!/usr/bin/env bash
set -e

echo "Starting diamOS overlay update..."

# Run pre-install hooks if present
if [ -f "./pre-install.sh" ]; then
    echo "Running pre-install hooks..."
    bash ./pre-install.sh
fi

# Deploy the overlay onto the root filesystem
if [ -d "./overlay" ]; then
    echo "Deploying filesystem overlay..."
    cp -avf ./overlay/. /
fi

# Reload system daemons
echo "Reloading system daemons..."
systemctl daemon-reload 2>/dev/null || true

# Run post-install hooks if present
if [ -f "./post-install.sh" ]; then
    echo "Running post-install hooks..."
    bash ./post-install.sh
fi

echo "Overlay deployment successful!"
exit 0
