# DIAMOS Custom Plymouth Theme

Place your custom Plymouth boot splash theme files here.

## Required Files

- `diamos.plymouth` — Theme descriptor
- `diamos.script` — Plymouth script (animation/logic)
- `logo.png` — Boot logo image
- `background.png` — Splash background (1920x1080 recommended)
- `progress_bar.png` — Progress bar graphic (optional)
- `spinner.png` — Spinner animation frame (optional)
- `throbber-*.png` — Throbber animation frames (optional)

## Example `diamos.plymouth`

```ini
[Plymouth Theme]
Name=DIAMOS
Description=DIAMOS boot splash
ModuleName=script

[script]
ImageDir=/usr/share/plymouth/themes/diamos
ScriptFile=/usr/share/plymouth/themes/diamos/diamos.script
```

## Example `diamos.script`

```
# Simple centered logo with spinner
wallpaper = Image("background.png");
logo = Image("logo.png");

screen_w = Window.GetWidth();
screen_h = Window.GetHeight();

wallpaper_sprite = Sprite(wallpaper);
wallpaper_sprite.SetPosition(0, 0, 0);

logo_sprite = Sprite(logo);
logo_sprite.SetPosition(screen_w/2 - logo.GetWidth()/2, screen_h/2 - logo.GetHeight()/2, 1);
```

## Activation

The build system will automatically set this as the default Plymouth theme
if `branding.yaml` has `plymouth.theme: "diamos"`.
