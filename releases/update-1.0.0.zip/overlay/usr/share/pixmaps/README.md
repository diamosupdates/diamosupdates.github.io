# DIAMOS Logos & Icons

Place system-level branding icons here.

## Expected Files

- `diamos-logo.png` — Main distro logo (256x256 recommended)
- `diamos-logo.svg` — Vector version of the logo
- `diamos-panel-icon.svg` — Small icon for the top panel / wingpanel (22x22 or 24x24)
- `diamos-icon-64.png` — 64px icon for use in About screen
- `diamos-icon-128.png` — 128px icon for installers and splash

## Usage

These are referenced by:
- `branding.yaml` → `lightdm.logo` and `panel.logo_icon`
- `/etc/os-release` display
- LightDM greeter
- About panel in System Settings
