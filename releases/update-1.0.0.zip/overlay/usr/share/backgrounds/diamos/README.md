# DIAMOS Wallpapers & Backgrounds

Place your custom wallpaper and background images here.

## Expected Files

- `default.png` — Default desktop wallpaper (3840x2160 or 1920x1080)
- `login.png` — Login screen / greeter background
- `lock.png` — Lock screen background (optional, defaults to login.png)

## Additional Wallpapers

You can add extra wallpapers here. They'll be available in:
`/usr/share/backgrounds/diamos/`

To make them appear in the wallpaper picker, also add an XML file at:
`overlay/usr/share/gnome-background-properties/diamos-wallpapers.xml`

## Recommended Formats

- PNG or JPEG
- Minimum resolution: 1920x1080
- Recommended: 3840x2160 for HiDPI support
