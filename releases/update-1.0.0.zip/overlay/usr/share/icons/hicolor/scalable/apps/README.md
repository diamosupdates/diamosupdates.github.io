# DIAMOS Custom App Icons

Place custom SVG app icons here to override defaults in the hicolor icon theme.

Files should be named to match the application's desktop file ID, e.g.:
- `io.elementary.files.svg`
- `io.elementary.terminal.svg`

These will take precedence over the elementary icon theme for apps you want to rebrand.
